package SportRecap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SportRecapV1Application {

	public static void main(String[] args) {
		SpringApplication.run(SportRecapV1Application.class, args);
	}

}
